link=("server.js")=True;
print("Bot has been Connected!");
link=("server.js")=False;
print("Bot is not Connected Please try Agin Next Time!");
