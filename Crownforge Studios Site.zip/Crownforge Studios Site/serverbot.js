//Pubilc and private Function For Bot!...

link("serverbot.py");

//Bot Connecting... Program.

linkbot()
{
    if (InputDeviceInfo  ("Device-info")) 
    {
        Device-info==DeviceMotionEvent(true);
    }
    else
    {
        Device-info==-DeviceMotionEvent(false);
    }
    RTCRtpSender()
    {
        if (DeviceMotionEvent=true) 
        {
            ("serverbot.py")=("BotNotFound!");    
        }
        else
        {
            DeviceMotionEvent=false
            ("serverbot.py")=("BotFinded!");
        }
    }
}

//Console for Bot To work and functions!

linkbotconsole()
{
    link==Device-info("Bot=True");
    linkbot=-DecompressionStream();

    print("Bot Has Been Started To Transfer you to Any links! With Safely!");
    if (print==true) 
    {
        linkbotconsole=true;
        serverbot.py=true
    }
    else
    {
        print=false;
        linkbotconsole=false,print.prototype("Bot Has not Connected To Server Please Try Agin!");
        serverbot.py==false;
    }
}